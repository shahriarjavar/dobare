# Shahriar Wallet — Preview Build

Shahriar is a Persian RTL Android UI preview for a TON wallet concept.

## Build on GitHub

The repository includes `.github/workflows/android.yml`.

1. Push the project files to the root of a GitHub repository.
2. Open **Actions**.
3. Select **Build Shahriar APK**.
4. Press **Run workflow** (or push to `main`).
5. When the run succeeds, download `Shahriar-debug-apk` from **Artifacts**.

The workflow installs Gradle 8.10.2 and builds `assembleDebug`.

## Important

This preview does **not** hold or send real cryptocurrency. Wallet creation/recovery and balances are local preview behavior. Do not enter a real seed phrase into this build.

The interface is intentionally designed as a polished visual prototype: Persian RTL, dark/blue wallet UI, assets, activity, DApps, settings, preview balance, and wallet setup screens.

Before any real-funds release, the wallet core, secure seed storage, address derivation, transaction preview/signing, network/API layer, QR, Jettons/NFTs, DApps and security testing must be implemented and independently tested.
