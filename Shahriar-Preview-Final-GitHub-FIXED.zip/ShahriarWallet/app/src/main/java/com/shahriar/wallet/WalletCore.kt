package com.shahriar.wallet

import android.content.Context

/** Preview build: UI and local state only. No real funds or signing are performed. */
class WalletCore(context: Context) {
    private val prefs = context.getSharedPreferences("shahriar_preview", Context.MODE_PRIVATE)
    fun getPreviewBalanceToman(): Long = prefs.getLong("preview_balance_toman", 125_000_000L)
    fun setPreviewBalanceToman(value: Long) { prefs.edit().putLong("preview_balance_toman", value.coerceAtLeast(0L)).apply() }
    fun isPreviewMode(): Boolean = prefs.getBoolean("preview_mode", true)
    fun setPreviewMode(enabled: Boolean) { prefs.edit().putBoolean("preview_mode", enabled).apply() }
    fun hasSavedWallet(): Boolean = prefs.getBoolean("wallet_added", false)
    fun clearWallet() { prefs.edit().putBoolean("wallet_added", false).apply() }
    suspend fun createNewWallet(): WalletSnapshot {
        prefs.edit().putBoolean("wallet_added", true).apply()
        return previewWallet()
    }
    suspend fun importWallet(words: String): WalletSnapshot {
        require(words.trim().split(Regex("\\s+")).size in 12..24) { "عبارت بازیابی باید حداقل ۱۲ کلمه داشته باشد" }
        prefs.edit().putBoolean("wallet_added", true).apply()
        return previewWallet()
    }
    suspend fun restoreSavedWallet(): WalletSnapshot? = if (hasSavedWallet()) previewWallet() else null
    private fun previewWallet() = WalletSnapshot("UQDemoShahriarWalletPreviewAddress000000000000000", 12_500_000_000L)
}

data class WalletSnapshot(val address: String, val balanceNano: Long)
