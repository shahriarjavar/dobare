package com.shahriar.wallet

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import androidx.navigation.compose.*
import kotlinx.coroutines.launch
import java.text.NumberFormat
import java.util.Locale

private val Bg = Color(0xFF030B16)
private val Surface = Color(0xFF071426)
private val Surface2 = Color(0xFF0B1C31)
private val Line = Color(0xFF14304C)
private val Accent = Color(0xFF1597FF)
private val Accent2 = Color(0xFF63C7FF)
private val Muted = Color(0xFF8295AA)
private val TextPrimary = Color(0xFFF4F8FC)
private val Positive = Color(0xFF41D99B)
private val Danger = Color(0xFFFF6B7A)

class MainActivity : ComponentActivity() {
    private val walletCore by lazy { WalletCore(applicationContext) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ShahriarApp(walletCore) }
    }
}

@Composable
private fun ShahriarApp(core: WalletCore) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Bg,
            surface = Surface,
            primary = Accent,
            onBackground = TextPrimary,
            onSurface = TextPrimary
        )
    ) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            val nav = rememberNavController()
            NavHost(navController = nav, startDestination = "home") {
                composable("home") { Home(nav, core) }
                composable("wallet") { WalletSetup(nav, core) }
                composable("send") { SendPage(nav, core) }
                composable("receive") { ReceivePage(nav, core) }
                composable("swap") { ActionPage(nav, "سواپ", Icons.Default.SwapHoriz, "تبدیل دارایی‌ها؛ اتصال DEX در لایه معاملاتی") }
                composable("assets") { Assets(nav, core) }
                composable("activity") { ActivityPage(nav) }
                composable("dapps") { ActionPage(nav, "DApps", Icons.Default.GridView, "اتصال امن به برنامه‌های غیرمتمرکز با TON Connect") }
                composable("settings") { Settings(nav, core) }
            }
        }
    }
}

@Composable
private fun Home(nav: NavHostController, core: WalletCore) {
    var wallet by remember { mutableStateOf<WalletSnapshot?>(null) }
    var loading by remember { mutableStateOf(true) }
    var preview by remember { mutableStateOf(core.isPreviewMode()) }
    var previewBalance by remember { mutableLongStateOf(core.getPreviewBalanceToman()) }

    suspend fun refresh() {
        loading = true
        wallet = runCatching { core.restoreSavedWallet() }.getOrNull()
        loading = false
    }

    LaunchedEffect(Unit) { refresh() }

    Scaffold(containerColor = Bg, bottomBar = { BottomBar(nav, "home") }) { pad ->
        LazyColumn(
            Modifier.fillMaxSize().background(Bg).padding(pad),
            contentPadding = PaddingValues(16.dp, 16.dp, 16.dp, 24.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Logo(50)
                    Spacer(Modifier.width(11.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Shahriar", fontSize = 20.sp, fontWeight = FontWeight.Black)
                        Text("TON Mainnet", color = Muted, fontSize = 11.sp)
                    }
                    IconButton({ nav.navigate("settings") }) {
                        Icon(Icons.Default.Settings, null, tint = Muted)
                    }
                }
            }
            item {
                BalanceCard(wallet, loading, preview, previewBalance) { nav.navigate("wallet") }
            }
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                    QuickAction("ارسال", Icons.Default.NorthEast) { nav.navigate("send") }
                    QuickAction("دریافت", Icons.Default.SouthWest) { nav.navigate("receive") }
                    QuickAction("سواپ", Icons.Default.SwapHoriz) { nav.navigate("swap") }
                    QuickAction("بیشتر", Icons.Default.MoreHoriz) { nav.navigate("assets") }
                }
            }
            item {
                NetworkCard(connected = wallet != null || preview)
            }
            item {
                SectionTitle("دارایی‌ها", "مشاهده همه") { nav.navigate("assets") }
            }
            item { AssetRow("TON", "The Open Network", if (wallet != null) formatTon(wallet!!.balanceNano) else "۰٫۰۰ TON", Icons.Default.CurrencyBitcoin) }
            item { AssetRow("USDT", "Tether USD", "۰٫۰۰ USDT", Icons.Default.AttachMoney) }
            item {
                Surface(Modifier.fillMaxWidth(), RoundedCornerShape(18.dp), Surface2, border = BorderStroke(1.dp, Line)) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Security, null, tint = Positive)
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text("کیف پول غیرامانی", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text("کلیدها فقط روی دستگاه شما نگهداری می‌شوند", color = Muted, fontSize = 10.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun BalanceCard(wallet: WalletSnapshot?, loading: Boolean, preview: Boolean, previewBalance: Long, onWallet: () -> Unit) {
    val shownToman = if (preview) previewBalance else (wallet?.balanceNano ?: 0L) / 1_000_000_000L
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(26.dp))
            .background(brushSurface())
            .border(BorderStroke(1.dp, Color(0xFF1E5B89)), RoundedCornerShape(26.dp))
    ) {
        Column(Modifier.padding(22.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(40.dp).clip(CircleShape).background(Color(0xFF0B3153)), contentAlignment = Alignment.Center) {
                    Text("T", color = Accent2, fontWeight = FontWeight.Black)
                }
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text("موجودی کل", color = Muted, fontSize = 11.sp)
                    Text(if (preview) "پیش‌نمایش رابط کاربری" else "TON Mainnet", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
                Icon(Icons.Default.Visibility, null, tint = Muted, modifier = Modifier.size(18.dp))
            }
            Spacer(Modifier.height(19.dp))
            Text(if (loading) "در حال دریافت…" else formatToman(shownToman), fontSize = 34.sp, fontWeight = FontWeight.Black)
            Text(if (wallet == null && !preview) "برای شروع، یک کیف پول اضافه کنید" else "تومان", color = Muted, fontSize = 11.sp)
            Spacer(Modifier.height(18.dp))
            if (wallet == null) {
                Button(onClick = onWallet, modifier = Modifier.fillMaxWidth().height(48.dp), shape = RoundedCornerShape(15.dp)) {
                    Icon(Icons.Default.Add, null)
                    Spacer(Modifier.width(6.dp))
                    Text("افزودن کیف پول")
                }
            } else {
                Text(shortAddress(wallet.address), color = Accent2, fontSize = 11.sp)
            }
        }
    }
}

@Composable private fun brushSurface() = Brush.linearGradient(listOf(Color(0xFF0A2843), Color(0xFF061323)))

@Composable
private fun QuickAction(label: String, icon: ImageVector, onClick: () -> Unit) {
    Surface(Modifier.weight(1f).clickable(onClick = onClick), RoundedCornerShape(18.dp), Surface2, border = BorderStroke(1.dp, Line)) {
        Column(Modifier.padding(vertical = 13.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(icon, null, tint = Accent2, modifier = Modifier.size(21.dp))
            Spacer(Modifier.height(5.dp))
            Text(label, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun NetworkCard(connected: Boolean) {
    Surface(Modifier.fillMaxWidth(), RoundedCornerShape(18.dp), Surface2, border = BorderStroke(1.dp, Line)) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(38.dp).clip(CircleShape).background(Accent), contentAlignment = Alignment.Center) { Text("T", fontWeight = FontWeight.Black) }
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text("شبکه TON", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Text(if (connected) "Mainnet • حالت پیش‌نمایش" else "Mainnet • کیف پولی اضافه نشده", color = if (connected) Positive else Muted, fontSize = 10.sp)
            }
            Icon(Icons.Default.ChevronLeft, null, tint = Muted)
        }
    }
}

@Composable private fun SectionTitle(title: String, action: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(title, fontSize = 17.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
        Text(action, color = Accent2, fontSize = 11.sp, modifier = Modifier.clickable(onClick = onClick))
    }
}

@Composable private fun AssetRow(name: String, subtitle: String, amount: String, icon: ImageVector) {
    Surface(Modifier.fillMaxWidth(), RoundedCornerShape(18.dp), Surface, border = BorderStroke(1.dp, Line)) {
        Row(Modifier.padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(42.dp).clip(CircleShape).background(Color(0xFF102E4B)), contentAlignment = Alignment.Center) { Icon(icon, null, tint = Accent2, modifier = Modifier.size(21.dp)) }
            Spacer(Modifier.width(11.dp))
            Column(Modifier.weight(1f)) { Text(name, fontWeight = FontWeight.Bold, fontSize = 13.sp); Text(subtitle, color = Muted, fontSize = 10.sp) }
            Column(horizontalAlignment = Alignment.End) { Text(amount, fontWeight = FontWeight.Bold, fontSize = 13.sp); Text("۰ تومان", color = Muted, fontSize = 10.sp) }
        }
    }
}

@Composable
private fun WalletSetup(nav: NavHostController, core: WalletCore) {
    var importMode by remember { mutableStateOf(false) }
    var words by remember { mutableStateOf("") }
    var result by remember { mutableStateOf<WalletSnapshot?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    var loading by remember { mutableStateOf(false) }
    var showWarning by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    Column(Modifier.fillMaxSize().background(Bg).padding(16.dp)) {
        Header(nav, "کیف پول")
        Text("کیف پول TON", fontSize = 27.sp, fontWeight = FontWeight.Black)
        Text("نسخه نمایشی رابط کاربری کیف پول TON", color = Muted, fontSize = 12.sp)
        Spacer(Modifier.height(20.dp))

        Surface(Modifier.fillMaxWidth(), RoundedCornerShape(18.dp), Color(0xFF1A1115), border = BorderStroke(1.dp, Color(0xFF51303A))) {
            Row(Modifier.padding(14.dp), verticalAlignment = Alignment.Top) {
                Icon(Icons.Default.WarningAmber, null, tint = Color(0xFFFFB0BA))
                Spacer(Modifier.width(9.dp))
                Text("عبارت بازیابی تنها راه دسترسی به دارایی است. آن را در اختیار هیچ‌کس قرار نده و از اسکرین‌شات گرفتن خودداری کن.", color = Color(0xFFFFD8DE), fontSize = 11.sp)
            }
        }
        Spacer(Modifier.height(12.dp))

        SetupCard("ساخت کیف پول جدید", "یک کیف پول V5R1 واقعی بساز", Icons.Default.AddCircle) {
            showWarning = true
        }
        Spacer(Modifier.height(10.dp))
        SetupCard("بازیابی کیف پول", "با عبارت بازیابی ۱۲ یا ۲۴ کلمه‌ای", Icons.Default.VpnKey) { importMode = !importMode }

        if (importMode) {
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(
                value = words,
                onValueChange = { words = it },
                modifier = Modifier.fillMaxWidth(),
                minLines = 4,
                shape = RoundedCornerShape(16.dp),
                label = { Text("عبارت بازیابی") },
                placeholder = { Text("کلمات را با فاصله وارد کنید") },
                supportingText = { Text("این عبارت فقط برای بازیابی روی همین دستگاه استفاده می‌شود.") }
            )
            Spacer(Modifier.height(9.dp))
            Button(
                enabled = !loading && words.isNotBlank(),
                onClick = {
                    loading = true; error = null
                    scope.launch {
                        runCatching { core.importWallet(words) }
                            .onSuccess { result = it; importMode = false }
                            .onFailure { error = it.message ?: "بازیابی ناموفق بود" }
                        loading = false
                    }
                },
                modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(15.dp)
            ) { Text(if (loading) "در حال بازیابی…" else "بازیابی کیف پول") }
        }

        result?.let {
            Spacer(Modifier.height(16.dp))
            WalletReadyCard(it)
        }
        error?.let { Text(it, color = Danger, fontSize = 12.sp, modifier = Modifier.padding(top = 10.dp)) }
    }

    if (showWarning) {
        AlertDialog(
            onDismissRequest = { showWarning = false },
            title = { Text("ذخیره امن عبارت بازیابی") },
            text = { Text("بعد از ساخت کیف پول، عبارت بازیابی را خارج از گوشی و روی یک محل امن یادداشت کن. اگر آن را از دست بدهی، Shahriar نمی‌تواند آن را بازیابی کند.") },
            confirmButton = {
                TextButton(onClick = {
                    showWarning = false; loading = true; error = null
                    scope.launch {
                        runCatching { core.createNewWallet() }
                            .onSuccess { result = it }
                            .onFailure { error = it.message ?: "ساخت کیف پول ناموفق بود" }
                        loading = false
                    }
                }) { Text("ساخت کیف پول") }
            },
            dismissButton = { TextButton(onClick = { showWarning = false }) { Text("انصراف") } }
        )
    }
}

@Composable private fun WalletReadyCard(wallet: WalletSnapshot) {
    val clipboard = LocalClipboardManager.current
    Surface(Modifier.fillMaxWidth(), RoundedCornerShape(20.dp), Surface2, border = BorderStroke(1.dp, Color(0xFF1C6D9F))) {
        Column(Modifier.padding(17.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.CheckCircle, null, tint = Positive)
                Spacer(Modifier.width(8.dp))
                Text("کیف پول آماده است", fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(10.dp))
            Text(wallet.address, color = Accent2, fontSize = 10.sp)
            Spacer(Modifier.height(8.dp))
            OutlinedButton(onClick = { clipboard.setText(AnnotatedString(wallet.address)) }, modifier = Modifier.fillMaxWidth()) { Text("کپی آدرس") }
        }
    }
}

@Composable private fun SetupCard(title: String, subtitle: String, icon: ImageVector, onClick: () -> Unit) {
    Surface(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).clickable(onClick = onClick), RoundedCornerShape(20.dp), Surface, border = BorderStroke(1.dp, Line)) {
        Row(Modifier.padding(17.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(45.dp).clip(RoundedCornerShape(15.dp)).background(Color(0xFF0A3151)), contentAlignment = Alignment.Center) { Icon(icon, null, tint = Accent2) }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) { Text(title, fontWeight = FontWeight.Bold); Text(subtitle, color = Muted, fontSize = 11.sp) }
            Icon(Icons.Default.ChevronLeft, null, tint = Muted)
        }
    }
}

@Composable
private fun SendPage(nav: NavHostController, core: WalletCore) {
    var address by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var comment by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    Column(Modifier.fillMaxSize().background(Bg).padding(16.dp)) {
        Header(nav, "ارسال")
        Text("ارسال TON", fontSize = 27.sp, fontWeight = FontWeight.Black)
        Text("قبل از ارسال، آدرس و مبلغ را چند بار بررسی کن.", color = Muted, fontSize = 12.sp)
        Spacer(Modifier.height(18.dp))
        OutlinedTextField(address, { address = it; error = null }, Modifier.fillMaxWidth(), label = { Text("آدرس مقصد") }, singleLine = true, shape = RoundedCornerShape(15.dp))
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(amount, { amount = it; error = null }, Modifier.fillMaxWidth(), label = { Text("مقدار TON") }, singleLine = true, shape = RoundedCornerShape(15.dp))
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(comment, { comment = it }, Modifier.fillMaxWidth(), label = { Text("یادداشت اختیاری") }, singleLine = true, shape = RoundedCornerShape(15.dp))
        Spacer(Modifier.height(14.dp))
        Button(
            onClick = { error = "برای جلوگیری از ارسال ناخواسته، لایه ساخت/Preview/Approve تراکنش باید با نسخه دقیق WalletKit در محیط Build تست و فعال شود." },
            modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(15.dp)
        ) { Text("بررسی تراکنش") }
        error?.let { Text(it, color = Danger, fontSize = 11.sp, modifier = Modifier.padding(top = 10.dp)) }
    }
}

@Composable
private fun ReceivePage(nav: NavHostController, core: WalletCore) {
    var wallet by remember { mutableStateOf<WalletSnapshot?>(null) }
    val clipboard = LocalClipboardManager.current
    LaunchedEffect(Unit) { wallet = runCatching { core.restoreSavedWallet() }.getOrNull() }
    Column(Modifier.fillMaxSize().background(Bg).padding(16.dp)) {
        Header(nav, "دریافت")
        Text("دریافت TON", fontSize = 27.sp, fontWeight = FontWeight.Black)
        Text("این آدرس را فقط برای شبکه TON Mainnet استفاده کن.", color = Muted, fontSize = 12.sp)
        Spacer(Modifier.height(28.dp))
        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            Box(Modifier.size(180.dp).clip(RoundedCornerShape(24.dp)).background(Color.White), contentAlignment = Alignment.Center) {
                Text(if (wallet == null) "QR\nپس از ساخت کیف پول" else "TON\nQR", color = Color.Black, textAlign = TextAlign.Center, fontWeight = FontWeight.Black)
            }
        }
        Spacer(Modifier.height(22.dp))
        Surface(Modifier.fillMaxWidth(), RoundedCornerShape(18.dp), Surface2, border = BorderStroke(1.dp, Line)) {
            Column(Modifier.padding(16.dp)) {
                Text("آدرس کیف پول", color = Muted, fontSize = 11.sp)
                Spacer(Modifier.height(7.dp))
                Text(wallet?.address ?: "ابتدا یک کیف پول بساز یا بازیابی کن", fontSize = 11.sp, color = Accent2)
                if (wallet != null) {
                    Spacer(Modifier.height(10.dp))
                    OutlinedButton(onClick = { clipboard.setText(AnnotatedString(wallet!!.address)) }, modifier = Modifier.fillMaxWidth()) { Text("کپی آدرس") }
                }
            }
        }
    }
}

@Composable private fun ActionPage(nav: NavHostController, title: String, icon: ImageVector, subtitle: String) {
    Column(Modifier.fillMaxSize().background(Bg).padding(16.dp)) {
        Header(nav, title)
        Spacer(Modifier.height(35.dp))
        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            Box(Modifier.size(92.dp).clip(CircleShape).background(Color(0xFF0A3151)), contentAlignment = Alignment.Center) { Icon(icon, null, tint = Accent2, modifier = Modifier.size(42.dp)) }
        }
        Spacer(Modifier.height(20.dp))
        Text(title, Modifier.fillMaxWidth(), textAlign = TextAlign.Center, fontSize = 25.sp, fontWeight = FontWeight.Black)
        Text(subtitle, Modifier.fillMaxWidth().padding(top = 6.dp), textAlign = TextAlign.Center, color = Muted, fontSize = 12.sp)
        Spacer(Modifier.height(20.dp))
        Surface(Modifier.fillMaxWidth(), RoundedCornerShape(18.dp), Surface2, border = BorderStroke(1.dp, Line)) {
            Text("این بخش در UI نهایی آماده است؛ برای عملیات مالی واقعی باید provider و flow تأیید تراکنش در Build نهایی فعال و تست شود.", Modifier.padding(18.dp), color = Muted, fontSize = 12.sp)
        }
    }
}

@Composable private fun Assets(nav: NavHostController, core: WalletCore) {
    var wallet by remember { mutableStateOf<WalletSnapshot?>(null) }
    LaunchedEffect(Unit) { wallet = runCatching { core.restoreSavedWallet() }.getOrNull() }
    Column(Modifier.fillMaxSize().background(Bg).padding(16.dp)) {
        Header(nav, "دارایی‌ها")
        Text("دارایی‌ها", fontSize = 26.sp, fontWeight = FontWeight.Black)
        Spacer(Modifier.height(14.dp))
        AssetRow("TON", "The Open Network", if (wallet != null) formatTon(wallet!!.balanceNano) else "۰٫۰۰ TON", Icons.Default.CurrencyBitcoin)
        Spacer(Modifier.height(8.dp))
        AssetRow("USDT", "Jetton on TON", "۰٫۰۰ USDT", Icons.Default.AttachMoney)
        Spacer(Modifier.height(8.dp))
        AssetRow("NFT", "NFT items", "۰ مورد", Icons.Default.Image)
    }
}

@Composable private fun ActivityPage(nav: NavHostController) {
    Column(Modifier.fillMaxSize().background(Bg).padding(16.dp)) {
        Header(nav, "تاریخچه تراکنش‌ها")
        Text("فعالیت‌ها", fontSize = 26.sp, fontWeight = FontWeight.Black)
        Spacer(Modifier.height(28.dp))
        Icon(Icons.Default.History, null, tint = Muted, modifier = Modifier.fillMaxWidth().height(54.dp))
        Spacer(Modifier.height(10.dp))
        Text("هنوز تراکنشی برای نمایش وجود ندارد", Modifier.fillMaxWidth(), textAlign = TextAlign.Center, color = Muted)
        Text("تاریخچه جعلی در Shahriar نمایش داده نمی‌شود.", Modifier.fillMaxWidth().padding(top = 6.dp), textAlign = TextAlign.Center, color = Muted, fontSize = 10.sp)
    }
}

@Composable
private fun Settings(nav: NavHostController, core: WalletCore) {
    var preview by remember { mutableStateOf(core.isPreviewMode()) }
    var previewBalance by remember { mutableLongStateOf(core.getPreviewBalanceToman()) }
    var text by remember { mutableStateOf(previewBalance.toString()) }
    Column(Modifier.fillMaxSize().background(Bg).padding(16.dp)) {
        Header(nav, "تنظیمات")
        Text("تنظیمات", fontSize = 26.sp, fontWeight = FontWeight.Black)
        Spacer(Modifier.height(14.dp))
        SettingRow("کیف پول", "ساخت، بازیابی و مدیریت کیف پول", Icons.Default.AccountBalanceWallet) { nav.navigate("wallet") }
        SettingRow("امنیت", "Android Keystore", Icons.Default.Security) {}
        SettingRow("شبکه", "TON Mainnet", Icons.Default.Language) {}
        Spacer(Modifier.height(8.dp))
        Surface(Modifier.fillMaxWidth(), RoundedCornerShape(18.dp), Surface2, border = BorderStroke(1.dp, Line)) {
            Column(Modifier.padding(16.dp)) {
                Text("پیش‌نمایش رابط کاربری", fontWeight = FontWeight.Bold)
                Text("فقط برای تست ظاهر؛ موجودی واقعی را تغییر نمی‌دهد.", color = Muted, fontSize = 10.sp)
                Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("فعال", Modifier.weight(1f), fontSize = 12.sp)
                    Switch(checked = preview, onCheckedChange = { preview = it; core.setPreviewMode(it) })
                }
                if (preview) {
                    OutlinedTextField(text, { text = it.filter(Char::isDigit) }, Modifier.fillMaxWidth(), label = { Text("موجودی نمایشی تومان") }, singleLine = true)
                    Spacer(Modifier.height(8.dp))
                    Button(onClick = { val value = text.toLongOrNull() ?: 0L; previewBalance = value; core.setPreviewBalanceToman(value) }, Modifier.fillMaxWidth()) { Text("ذخیره") }
                }
            }
        }
        Spacer(Modifier.height(18.dp))
        Text("Shahriar", Modifier.fillMaxWidth(), textAlign = TextAlign.Center, fontWeight = FontWeight.Black)
        Text("نسخه 1.0.0-preview", Modifier.fillMaxWidth(), textAlign = TextAlign.Center, color = Muted, fontSize = 11.sp)
    }
}

@Composable private fun SettingRow(title: String, subtitle: String, icon: ImageVector, onClick: () -> Unit) {
    Surface(Modifier.fillMaxWidth().padding(bottom = 9.dp).clickable(onClick = onClick), RoundedCornerShape(17.dp), Surface, border = BorderStroke(1.dp, Line)) {
        Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = Accent2, modifier = Modifier.size(22.dp))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) { Text(title, fontWeight = FontWeight.Bold, fontSize = 13.sp); Text(subtitle, color = Muted, fontSize = 10.sp) }
            Icon(Icons.Default.ChevronLeft, null, tint = Muted)
        }
    }
}

@Composable private fun Header(nav: NavHostController, title: String) {
    Row(Modifier.fillMaxWidth().padding(bottom = 14.dp), verticalAlignment = Alignment.CenterVertically) {
        IconButton({ nav.popBackStack() }) { Icon(Icons.Default.ArrowForward, null) }
        Text(title, fontSize = 20.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable private fun BottomBar(nav: NavHostController, current: String) {
    NavigationBar(containerColor = Color(0xFF04101D)) {
        NavItem(nav, "home", current == "home", Icons.Default.Home, "خانه")
        NavItem(nav, "assets", current == "assets", Icons.Default.AccountBalanceWallet, "دارایی‌ها")
        NavItem(nav, "activity", current == "activity", Icons.Default.History, "تراکنش‌ها")
        NavItem(nav, "dapps", current == "dapps", Icons.Default.GridView, "DApps")
    }
}

@Composable private fun NavItem(nav: NavHostController, route: String, selected: Boolean, icon: ImageVector, label: String) {
    NavigationBarItem(selected = selected, onClick = { nav.navigate(route) }, icon = { Icon(icon, null) }, label = { Text(label, fontSize = 9.sp) })
}

@Composable private fun Logo(size: Int) {
    Box(Modifier.size(size.dp).clip(RoundedCornerShape((size / 3).dp)).background(Brush.linearGradient(listOf(Color(0xFF0D75D8), Color(0xFF62C7FF)))), contentAlignment = Alignment.Center) {
        Text("S", color = Color.White, fontSize = (size / 2.1).sp, fontWeight = FontWeight.Black)
    }
}

private fun shortAddress(address: String): String = if (address.length > 18) address.take(8) + "…" + address.takeLast(8) else address

private fun formatTon(nano: Long): String = String.format(Locale.US, "%.4f TON", nano / 1_000_000_000.0)

private fun formatToman(value: Long): String = NumberFormat.getNumberInstance(Locale("fa", "IR")).format(value) + " تومان"
