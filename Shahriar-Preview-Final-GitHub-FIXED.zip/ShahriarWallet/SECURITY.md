# Security notes

- Never commit a mnemonic, private key, API key, or release keystore.
- Never print seed/private-key material to logs, crash reports, analytics, or screenshots.
- The local mnemonic is encrypted with an AES-GCM key held by Android Keystore.
- A real release should gate wallet use with a user-selected PIN and/or platform biometric authentication.
- Transaction requests must be validated and shown in a confirmation screen before signing.
- Preview/demo balance must remain visibly identified as preview and must never be mixed with on-chain balance.
